package com.example.android.basicweather

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.*

class WeatherListAdapter(private val onWeatherDetailClick: (ForecastPeriod) -> Unit)
    : RecyclerView.Adapter<WeatherListAdapter.ViewHolder>() {
    var weatherList = listOf<ForecastPeriod>()


    fun updateWeatherList(newWeatherList: List<ForecastPeriod>?) {
        weatherList = newWeatherList ?: listOf()
        notifyDataSetChanged()
    }

    override fun getItemCount() = this.weatherList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.weather_list_item, parent, false)
        return ViewHolder(view, onWeatherDetailClick)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(weatherList[position])
    }
    class ViewHolder(view: View, val onClick: (ForecastPeriod) -> Unit) : RecyclerView.ViewHolder(view) {
        private val date: TextView = view.findViewById(R.id.item_date)
        private val time: TextView = view.findViewById(R.id.item_time)
        private val high: TextView = view.findViewById(R.id.item_high)
        private val low: TextView = view.findViewById(R.id.item_low)
        private val precip: TextView = view.findViewById(R.id.item_precip)
        private val descShort: TextView = view.findViewById(R.id.item_short)
        private lateinit var currentForecastPeriod: ForecastPeriod

        init {
            view.setOnClickListener{
                currentForecastPeriod?.let(onClick)
            }
        }

        fun bind (forecastPeriod: ForecastPeriod) {
            currentForecastPeriod = forecastPeriod
            val findTime = Instant.ofEpochSecond(currentForecastPeriod!!.date)
            val dateTime = LocalDateTime.ofInstant(findTime, ZoneId.systemDefault())
            val newDate: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM d")
            val newTime: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm a")
            this.time.text = dateTime.format(newTime)
            this.date.text = dateTime.format(newDate)
            this.high.text = currentForecastPeriod.tempData.high.toInt().toString() + "°F"
            this.low.text = currentForecastPeriod.tempData.low.toInt().toString() + "°F"
            this.precip.text = (currentForecastPeriod.pop * 100).toInt().toString() + "% precip"
            this.descShort.text = currentForecastPeriod.weather[0].shortDesc
        }
    }
}